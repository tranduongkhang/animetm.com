const loginBtn = document.getElementById("loginBtn");
const loginPopup = document.getElementById("loginPopup");
const closePopup = document.getElementById("closePopup");

loginBtn.addEventListener("click", () => {
  loginPopup.classList.remove("hidden");
});

closePopup.addEventListener("click", () => {
  loginPopup.classList.add("hidden");
});
